import "./App.css";
import "./assets/sass/main.scss";
import RoutePage from "./RoutePage";

function App() {
  return (
    <div className="App">
      <RoutePage />
    </div>
  );
}

export default App;
